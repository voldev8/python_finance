.. gs_quant documentation master file, created by
   sphinx-quickstart on Sat Jan  5 20:53:00 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2
   :caption: Packages

   data
   datetime
   instrument
   market
   risk
   timeseries


Indices and tables
==================

* :ref:`genindex`


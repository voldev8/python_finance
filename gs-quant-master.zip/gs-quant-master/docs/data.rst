Data Package
============

.. currentmodule:: gs_quant.data

.. autosummary::
   :toctree: classes

   Dataset

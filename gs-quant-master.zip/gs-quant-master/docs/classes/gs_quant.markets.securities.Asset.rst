Asset
==================================

.. currentmodule:: gs_quant.markets.securities

.. autoclass:: Asset

   .. automethod:: get_identifiers
   
   .. rubric:: Methods

   .. autosummary::
   
      ~Asset.__init__
      ~Asset.get_identifiers
      ~Asset.get_type
   
   

   
   
   
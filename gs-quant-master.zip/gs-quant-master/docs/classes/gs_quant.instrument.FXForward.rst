FXForward
=========

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: FXForward

   
   .. rubric:: Properties
   
   
   
   
   
   .. autoattribute:: forwardRate
   
   
   .. autoattribute:: notional
   
   
   .. autoattribute:: pair
   
   
   .. autoattribute:: settlementDate
   
   
   
   
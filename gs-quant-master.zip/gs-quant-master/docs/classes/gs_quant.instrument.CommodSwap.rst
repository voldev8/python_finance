CommodSwap
==========

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: CommodSwap

   
   .. rubric:: Properties
   
   
   
   
   
   .. autoattribute:: calculationPeriodFrequency
   
   
   .. autoattribute:: calculationPeriods
   
   
   .. autoattribute:: commodity
   
   
   .. autoattribute:: commodityReferencePrice
   
   
   .. autoattribute:: currency
   
   
   .. autoattribute:: notionalAmount
   
   
   .. autoattribute:: start
   
   
   
   
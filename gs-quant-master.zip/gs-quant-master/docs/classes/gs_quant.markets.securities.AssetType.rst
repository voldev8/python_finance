AssetType
======================================

.. currentmodule:: gs_quant.markets.securities

.. autoclass:: AssetType

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AssetType.BASKET
      ~AssetType.ETF
      ~AssetType.FUTURE
      ~AssetType.INDEX
      ~AssetType.STOCK
   
   
FXOption
========

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: FXOption

   
   .. rubric:: Properties
   
   
   
   
   
   .. autoattribute:: callAmount
   
   
   .. autoattribute:: callCurrency
   
   
   .. autoattribute:: expirationDate
   
   
   .. autoattribute:: optionType
   
   
   .. autoattribute:: premium
   
   
   .. autoattribute:: putAmount
   
   
   .. autoattribute:: putCurrency
   
   
   .. autoattribute:: strike
   
   
   
   
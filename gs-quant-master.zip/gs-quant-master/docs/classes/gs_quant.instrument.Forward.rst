Forward
=======

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: Forward

   
   .. rubric:: Properties
   
   
   
   
   
   .. autoattribute:: currency
   
   
   .. autoattribute:: expirationDate
   
   
   
   
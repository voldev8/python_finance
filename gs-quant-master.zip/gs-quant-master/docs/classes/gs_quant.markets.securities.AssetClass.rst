AssetClass
=======================================

.. currentmodule:: gs_quant.markets.securities

.. autoclass:: AssetClass

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AssetClass.Cash
      ~AssetClass.Commod
      ~AssetClass.Credit
      ~AssetClass.Cross_Asset
      ~AssetClass.Equity
      ~AssetClass.FX
      ~AssetClass.Fund
      ~AssetClass.Loan
      ~AssetClass.Mortgage
      ~AssetClass.Rates
   
   
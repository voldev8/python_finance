GsContentApi
============

.. currentmodule:: gs_quant.api.gs.content

.. autoclass:: GsContentApi


   .. rubric:: Methods

   .. automethod:: get_contents
   .. automethod:: get_text


   
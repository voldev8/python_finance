Priceable
=========

.. currentmodule:: gs_quant.base

.. autoclass:: Priceable

   .. rubric:: Methods

   .. automethod:: as_dict
   .. automethod:: calc
   .. automethod:: dollar_price
   .. automethod:: from_dict
   .. automethod:: price
   .. automethod:: resolve

   
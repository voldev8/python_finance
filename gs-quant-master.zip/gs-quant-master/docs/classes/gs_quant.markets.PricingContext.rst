PricingContext
==============

.. currentmodule:: gs_quant.markets

.. autoclass:: PricingContext

   .. automethod:: __init__

   .. rubric:: Methods

   .. automethod:: calc
   .. automethod:: resolve_fields

   .. rubric:: Properties

   .. autoattribute:: pricing_date
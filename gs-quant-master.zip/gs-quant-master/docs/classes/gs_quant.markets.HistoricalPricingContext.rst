HistoricalPricingContext
========================

.. currentmodule:: gs_quant.markets

.. autoclass:: HistoricalPricingContext

   .. automethod:: __init__

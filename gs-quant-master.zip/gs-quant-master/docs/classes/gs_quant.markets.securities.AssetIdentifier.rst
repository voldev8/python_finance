AssetIdentifier
============================================

.. currentmodule:: gs_quant.markets.securities

.. autoclass:: AssetIdentifier

   
   .. automethod:: __init__

   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~AssetIdentifier.BLOOMBERG_COMPOSITE_ID
      ~AssetIdentifier.BLOOMBERG_ID
      ~AssetIdentifier.CUSIP
      ~AssetIdentifier.ISIN
      ~AssetIdentifier.MARQUEE_ID
      ~AssetIdentifier.REUTERS_ID
      ~AssetIdentifier.SEDOL
      ~AssetIdentifier.TICKER
   
   
EqOption
========

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: EqOption

   
   .. rubric:: Properties
   
   
   
   
   .. autoattribute:: asset
   
   
   
   .. autoattribute:: currency
   
   
   .. autoattribute:: exchange
   
   
   .. autoattribute:: expirationDate
   
   
   .. autoattribute:: multiplier
   
   
   .. autoattribute:: numberOfOptions
   
   
   .. autoattribute:: optionStyle
   
   
   .. autoattribute:: optionType
   
   
   .. autoattribute:: premium
   
   
   .. autoattribute:: settlementDate
   
   
   .. autoattribute:: strikePrice
   
   
   
   
Security
========

For methods of this class, see :doc:`gs_quant.base.Priceable`

.. currentmodule:: gs_quant.instrument

.. autoclass:: Security

   .. automethod:: __init__
   
   .. rubric:: Properties


   .. autoattribute:: bbid
   
   
   .. autoattribute:: cusip
   
   
   .. autoattribute:: isin
   
   
   .. autoattribute:: primeId


   .. autoattribute:: ric
   
   


   
   
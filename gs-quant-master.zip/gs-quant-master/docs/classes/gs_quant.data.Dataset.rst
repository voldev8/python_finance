Dataset
=======

.. currentmodule:: gs_quant.data

.. autoclass:: Dataset

   .. automethod:: __init__


   .. rubric:: Methods

   .. automethod:: get_coverage
   .. automethod:: get_data
   .. automethod:: get_data_last
   .. automethod:: get_data_series


   .. rubric:: Properties

   .. autoattribute:: id

   
point\_sort\_order
==================

.. currentmodule:: gs_quant.datetime.point

.. autofunction:: point_sort_order
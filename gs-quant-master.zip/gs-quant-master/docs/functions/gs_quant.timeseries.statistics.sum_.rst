sum
=====================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: sum_
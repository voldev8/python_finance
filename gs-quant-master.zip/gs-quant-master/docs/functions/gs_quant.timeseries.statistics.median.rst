median
======================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: median
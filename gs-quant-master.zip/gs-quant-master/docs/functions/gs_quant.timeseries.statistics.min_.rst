min_
=====================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: min_
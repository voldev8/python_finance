exp
================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: exp
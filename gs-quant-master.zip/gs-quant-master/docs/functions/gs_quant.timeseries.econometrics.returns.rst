returns
=========================================

.. currentmodule:: gs_quant.timeseries.econometrics

.. autofunction:: returns
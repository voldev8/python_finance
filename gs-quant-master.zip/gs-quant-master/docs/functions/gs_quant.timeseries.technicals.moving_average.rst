moving\_average
===============================================

.. currentmodule:: gs_quant.timeseries.technicals

.. autofunction:: moving_average
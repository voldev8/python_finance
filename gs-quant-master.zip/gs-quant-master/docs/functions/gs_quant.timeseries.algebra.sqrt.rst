sqrt
=================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: sqrt
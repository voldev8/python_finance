diff
==================================

.. currentmodule:: gs_quant.timeseries.analysis

.. autofunction:: diff
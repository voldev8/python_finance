is\_business\_day
=========================================

.. currentmodule:: gs_quant.datetime.date

.. autofunction:: is_business_day
volatility
============================================

.. currentmodule:: gs_quant.timeseries.econometrics

.. autofunction:: volatility
max_
=====================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: max_
lag
=================================

.. currentmodule:: gs_quant.timeseries.analysis

.. autofunction:: lag
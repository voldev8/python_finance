mode
====================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: mode
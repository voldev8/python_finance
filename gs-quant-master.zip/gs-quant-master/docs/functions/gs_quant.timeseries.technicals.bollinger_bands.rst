bollinger\_bands
================================================

.. currentmodule:: gs_quant.timeseries.technicals

.. autofunction:: bollinger_bands
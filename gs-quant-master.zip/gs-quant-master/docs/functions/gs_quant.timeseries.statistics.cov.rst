cov
===================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: cov
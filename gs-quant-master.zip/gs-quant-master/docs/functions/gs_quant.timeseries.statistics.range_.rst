range_
=======================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: range_
correlation
=============================================

.. currentmodule:: gs_quant.timeseries.econometrics

.. autofunction:: correlation
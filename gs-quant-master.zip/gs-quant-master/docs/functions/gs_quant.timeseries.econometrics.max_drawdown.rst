max\_drawdown
===============================================

.. currentmodule:: gs_quant.timeseries.econometrics

.. autofunction:: max_drawdown
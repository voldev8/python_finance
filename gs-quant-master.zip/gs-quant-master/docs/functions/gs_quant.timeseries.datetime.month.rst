month
===================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: month
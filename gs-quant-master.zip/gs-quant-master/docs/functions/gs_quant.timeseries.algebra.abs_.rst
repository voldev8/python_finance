abs_
==================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: abs_
count
===================================

.. currentmodule:: gs_quant.timeseries.analysis

.. autofunction:: count
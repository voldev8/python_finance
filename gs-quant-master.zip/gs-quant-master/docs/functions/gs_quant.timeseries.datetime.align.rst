align
===================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: align
beta
======================================

.. currentmodule:: gs_quant.timeseries.econometrics

.. autofunction:: beta
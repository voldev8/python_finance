quarter
=====================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: quarter
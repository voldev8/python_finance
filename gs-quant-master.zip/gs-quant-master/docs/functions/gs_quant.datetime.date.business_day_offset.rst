business\_day\_offset
=============================================

.. currentmodule:: gs_quant.datetime.date

.. autofunction:: business_day_offset
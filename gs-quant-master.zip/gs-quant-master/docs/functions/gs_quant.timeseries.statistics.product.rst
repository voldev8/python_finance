product
=======================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: product
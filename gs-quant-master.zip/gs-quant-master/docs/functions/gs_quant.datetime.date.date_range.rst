date\_range
===========

.. currentmodule:: gs_quant.datetime.date

.. autofunction:: date_range
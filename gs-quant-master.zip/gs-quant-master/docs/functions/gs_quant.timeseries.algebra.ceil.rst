ceil
=================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: ceil
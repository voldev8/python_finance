generate\_series
================================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: generate_series
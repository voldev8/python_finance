last
==================================

.. currentmodule:: gs_quant.timeseries.analysis

.. autofunction:: last
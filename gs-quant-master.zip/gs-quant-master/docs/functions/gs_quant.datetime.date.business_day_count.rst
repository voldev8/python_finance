business\_day\_count
============================================

.. currentmodule:: gs_quant.datetime.date

.. autofunction:: business_day_count
std
===================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: std
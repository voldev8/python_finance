first
===================================

.. currentmodule:: gs_quant.timeseries.analysis

.. autofunction:: first
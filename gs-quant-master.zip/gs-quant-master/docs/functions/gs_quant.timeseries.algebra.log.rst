log
================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: log
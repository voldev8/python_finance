divide
===================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: divide
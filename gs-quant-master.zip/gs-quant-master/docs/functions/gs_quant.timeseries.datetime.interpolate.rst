interpolate
=========================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: interpolate
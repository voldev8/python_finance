year
==================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: year
zscores
=======================================

.. currentmodule:: gs_quant.timeseries.statistics

.. autofunction:: zscores
add
================================

.. currentmodule:: gs_quant.timeseries.algebra

.. autofunction:: add
value
===================================

.. currentmodule:: gs_quant.timeseries.datetime

.. autofunction:: value